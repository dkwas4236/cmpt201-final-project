
void createWindow();


void rect(int ,int , int  ,int );
