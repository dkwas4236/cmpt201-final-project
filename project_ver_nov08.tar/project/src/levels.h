void splash();

void level1();


void level2();


void level3();

void display_level(int);


