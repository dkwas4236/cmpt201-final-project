in this update to the code i have restructred the lab to fix requirements with all the directorys info is under (RESTRUCTURE)
i also modulated the lab to that there are three different.c files with corosponding .h files info in (NEW FILES)

!!!note!!!: "main.c"= the new working main function and file; "oldMain.c" = the old main function that was modulated 

RESTRUCTURE
the main directory is "project" inside that directory is "src" this is where all of the files are including the working Makefile





NEW FILES 
!!!note!!!: all of the .c files have a .h header file with the same name 

main.c: this contains the main calls for displaying splash and calling display functions 

levels.c: this contains all of the leves and function for determining leves 

game_obj.c: this contains game object like the window creation function and the rect function

Makefile: i have built the make file in the src folder that makes .0 and does pattern expansion 


